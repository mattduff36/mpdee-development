# PowerShell script to download and pre-configure RustDesk client
Set-ExecutionPolicy RemoteSigned -Scope CurrentUser -Force

# Check if the script is running with administrator privileges
if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    # If not, relaunch the script with administrator privileges
    Write-Host "Requesting administrator privileges..."
    try {
        $arguments = "& '" + $myinvocation.MyCommand.Path + "'"
        Start-Process powershell -Verb runAs -ArgumentList $arguments
        exit
    } catch {
        Write-Error "Failed to elevate privileges: $($_.Exception.Message)"
        exit 1
    }
}

# Set variables
$RustDeskVersion = "1.3.9"
$DownloadURL = "https://github.com/rustdesk/rustdesk/releases/download/$RustDeskVersion/rustdesk-$RustDeskVersion-windows.exe"
$OutputFile = "rustdesk.exe"
$ScriptPath = Split-Path -parent $MyInvocation.MyCommand.Definition
$NewConfigFile = Join-Path $ScriptPath "RustDesk2_new.toml"
$ConfigFile = "$env:APPDATA\RustDesk\config\RustDesk2.toml"

# Download RustDesk client
Write-Host "Downloading RustDesk client from $DownloadURL"
try {
    Invoke-WebRequest -Uri $DownloadURL -OutFile $OutputFile
} catch {
    Write-Error "Failed to download RustDesk client: $($_.Exception.Message)"
    exit 1
}

# Check if the file was downloaded successfully
if (-not (Test-Path $OutputFile)) {
    Write-Error "RustDesk client download failed."
    exit 1
}

# Pre-configure RustDesk with server details
Write-Host "Pre-configuring RustDesk with server details..."

# Stop RustDesk
Write-Host "Stopping RustDesk..."
Stop-Process -Name rustdesk -Force -ErrorAction SilentlyContinue

# Check if the new config file exists
if (-not (Test-Path $NewConfigFile)) {
    Write-Error "New config file not found: $NewConfigFile"
    exit 1
}

# Copy the new config file to the RustDesk config directory
Write-Host "Copying new config file..."
try {
    Copy-Item -Path $NewConfigFile -Destination $ConfigFile -Force
} catch {
    Write-Error "Failed to copy config file: $($_.Exception.Message)"
    exit 1
}

# Start RustDesk
Write-Host "Starting RustDesk..."
Start-Process -FilePath "C:\Program Files\RustDesk\rustdesk.exe" -ErrorAction SilentlyContinue

Write-Host "Server settings updated successfully."

Write-Host "RustDesk client downloaded and pre-configured successfully."
Write-Host "Run the '$OutputFile' executable to start RustDesk."
Write-Host "Please run the 'update.bat' file to configure the server settings. Ensure you run as administrator."
